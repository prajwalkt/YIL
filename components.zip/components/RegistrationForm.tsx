"use client";

import { useState } from "react";
import {
  User,
  Mail,
  Phone,
  Building2,
  Globe2,
  GraduationCap,
  BookOpen,
  MessageSquare,
  ChevronDown,
  ArrowRight,
} from "lucide-react";

interface Props {
  selectedCountry?: string;
  onSuccess?: () => void;
}

export default function RegistrationForm({
  selectedCountry = "India",
  onSuccess,
}: Props) {

  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    organization: "",
    country: selectedCountry,
    graduationYear: "",
    course: "",
    trainingMode: "Online training",
    sponsor: "Self",
    instructions: "",
  });
  

  const countries = [
    "India",
    "Japan",
    "Singapore",
    "Malaysia",
    "Thailand",
    "Vietnam",
    "Indonesia",
    "Philippines",
    "Australia",
    "New Zealand",
    "Others",
  ];

  const courses = [
    "CENTUM VP DCS Operation",
    "CENTUM VP DCS Fundamentals",
    "CENTUM VP DCS Engineering",
    "CENTUM VP DCS Fundamentals & Engineering",
    "CENTUM VP DCS Engineering & Maintenance",
    "CENTUM VP DCS Maintenance",
    "CENTUM VP DCS Advanced Engineering",
    "CENTUM VP DCS Batch Engineering",
    "CENTUM VP DCS AD Suite Engineering",
    "Consolidated Alarm Management System",
    "SEBOL Programming",
    "STARDOM NCS with FAST/TOOLS SCADA",
    "STARDOM NCS with CI Server",
    "STARDOM NCS Engineering",
    "FAST/TOOLS SCADA Operations",
    "FAST/TOOLS SCADA Engineering",
    "CI Server Operations",
    "CI Server Engineering",
    "Field Bus Basics & Engineering",
    "Field Bus Engineering & PRM",
    "PROFIBUS Basics & Engineering",
    "Industrial Communication Protocols",
    "Field Instruments for Process Control",
    "Asset Management Software - PRM",
    "Cyber Security for Industrial Control System",
    "PROSAFE RS Operations",
    "PROSAFE RS Engineering",
    "PROSAFE RS Advanced Engineering",
    "Functional Safety for End Users",
  ];
  const courseFees: { [key: string]: { inr: string; usd: string } } = {
  "CENTUM VP DCS Operation": {
    inr: "₹23,000",
    usd: "$270",
  },

  "CENTUM VP DCS Engineering & Maintenance": {
    inr: "₹65,000",
    usd: "$760",
  },

  "CENTUM VP DCS Fundamentals & Engineering": {
    inr: "₹1",
    usd: "$1",
  },
};

  const handleChange = (

    e: React.ChangeEvent<
      HTMLInputElement |
      HTMLTextAreaElement |
      HTMLSelectElement
    >
  ) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };
const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();

  setLoading(true);

  try {
    const data = new FormData();

    Object.entries(form).forEach(([key, value]) => {
      data.append(key, value);
    });

    const response = await fetch("/api/register", {
      method: "POST",
      body: data,
    });

    const result = await response.json();

    if (result.success) {
      if (onSuccess) {
        onSuccess();
      } else {
        alert("Registration Successful");
      }
    } else {
      alert(result.message);
    }
  } catch (error) {
    console.error(error);
    alert("Server Error");
  } finally {
    setLoading(false);
  }
};
return (
  <div className="w-full h-full overflow-y-auto bg-[#F0EBF8] py-10 px-5">

    <div className="max-w-4xl mx-auto">

      {/* Header */}

      <div className="bg-white rounded-2xl shadow-md border-t-12 border-[#673AB7] overflow-hidden">

        <div className="px-10 py-8">

          <div className="flex justify-between items-center">

            <div>

              <h1 className="text-4xl font-bold text-slate-900">
                Yokogawa Training Services
              </h1>

              <p className="text-slate-500 mt-3 text-lg">
                Course Registration Form
              </p>

            </div>

            <div className="w-16 h-16 rounded-full bg-[#673AB7] text-white flex items-center justify-center text-3xl font-bold">
              Y
            </div>

          </div>

          <div className="mt-8 h-2 rounded-full bg-slate-200">

            <div className="w-1/2 h-full rounded-full bg-[#673AB7]" />

          </div>

          <p className="text-sm text-slate-500 mt-4">
            Step 1 of 2
          </p>

        </div>

      </div>

      <form
        onSubmit={handleSubmit}
        className="space-y-6 mt-8"
      >

        {/* Personal Information */}

        <div className="bg-white rounded-2xl shadow-md p-8">

          <h2 className="text-2xl font-bold mb-8 text-slate-800">
            Personal Information
          </h2>
<div className="mb-8">

<label className="text-sm font-semibold text-slate-500">
Full Name *
</label>

<div className="mt-2 relative">

<User
size={20}
className="absolute left-4 top-4 text-slate-400"
/>

<input
type="text"
name="name"
value={form.name}
onChange={handleChange}
required
className="w-full pl-12 pr-5 py-4 rounded-xl border border-slate-300 focus:border-[#673AB7] focus:ring-4 focus:ring-purple-200 outline-none transition"
/>

</div>

</div>
<div className="mb-8">

<label className="text-sm font-semibold text-slate-500">
Email Address *
</label>

<div className="mt-2 relative">

<Mail
size={20}
className="absolute left-4 top-4 text-slate-400"
/>

<input
type="email"
name="email"
value={form.email}
onChange={handleChange}
required
className="w-full pl-12 pr-5 py-4 rounded-xl border border-slate-300 focus:border-[#673AB7] focus:ring-4 focus:ring-purple-200 outline-none transition"
/>

</div>

</div>
<div className="mb-8">

<label className="text-sm font-semibold text-slate-500">
Phone Number *
</label>

<div className="mt-2 relative">

<Phone
size={20}
className="absolute left-4 top-4 text-slate-400"
/>

<input
type="text"
name="phone"
value={form.phone}
onChange={handleChange}
required
className="w-full pl-12 pr-5 py-4 rounded-xl border border-slate-300 focus:border-[#673AB7] focus:ring-4 focus:ring-purple-200 outline-none transition"
/>

</div>

</div>
<div className="mb-4">

<label className="text-sm font-semibold text-slate-500">
Organization
</label>

<div className="mt-2 relative">

<Building2
size={20}
className="absolute left-4 top-4 text-slate-400"
/>

<input
type="text"
name="organization"
value={form.organization}
onChange={handleChange}
className="w-full pl-12 pr-5 py-4 rounded-xl border border-slate-300 focus:border-[#673AB7] focus:ring-4 focus:ring-purple-200 outline-none transition"
/>

</div>

</div>

</div>
{/* Training Information */}

<div className="bg-white rounded-2xl shadow-md p-8">

  <h2 className="text-2xl font-bold mb-8 text-slate-800">
    Training Information
  </h2>

  <div className="mb-8">

    <label className="text-sm font-semibold text-slate-500">
      Country *
    </label>

    <div className="relative mt-2">

      <Globe2
        size={20}
        className="absolute left-4 top-4 text-slate-400"
      />

      <select
        name="country"
        value={form.country}
        onChange={handleChange}
        className="w-full pl-12 pr-10 py-4 rounded-xl border border-slate-300 appearance-none focus:border-[#673AB7] focus:ring-4 focus:ring-purple-200 outline-none"
      >
        {countries.map((country) => (
          <option key={country}>{country}</option>
        ))}
      </select>

      <ChevronDown
        size={18}
        className="absolute right-4 top-5 text-slate-400"
      />

    </div>

  </div>

  <div className="mb-8">

    <label className="text-sm font-semibold text-slate-500">
      Graduation Year
    </label>

    <div className="relative mt-2">

      <GraduationCap
        size={20}
        className="absolute left-4 top-4 text-slate-400"
      />

      <input
        type="text"
        name="graduationYear"
        value={form.graduationYear}
        onChange={handleChange}
        className="w-full pl-12 pr-5 py-4 rounded-xl border border-slate-300 focus:border-[#673AB7] focus:ring-4 focus:ring-purple-200 outline-none"
      />

    </div>

  </div>

  <div className="mb-8">

    <label className="text-sm font-semibold text-slate-500">
      Course *
    </label>

    <div className="relative mt-2">

      <BookOpen
        size={20}
        className="absolute left-4 top-4 text-slate-400"
      />

      <select
 
        name="course"
        value={form.course}
        onChange={handleChange}
        required
        className="w-full pl-12 pr-10 py-4 rounded-xl border border-slate-300 appearance-none focus:border-[#673AB7] focus:ring-4 focus:ring-purple-200 outline-none"
      >
        {form.course && courseFees[form.course] && (
  <div className="mt-4 rounded-xl border border-green-300 bg-green-50 p-4">
    <h3 className="font-bold text-green-700 mb-2">
      Course Fee
    </h3>

    <div className="flex justify-between text-lg">
      <span>INR</span>
      <span className="font-bold">
        {courseFees[form.course].inr}
      </span>
    </div>

    <div className="flex justify-between text-lg mt-2">
      <span>USD</span>
      <span className="font-bold">
        {courseFees[form.course].usd}
      </span>
    </div>
  </div>
)}

        <option value="">
          Select Course
        </option>

        {courses.map((course) => (
          <option
            key={course}
            value={course}
          >
            {course}
          </option>
        ))}

      </select>

      <ChevronDown
        size={18}
        className="absolute right-4 top-5 text-slate-400"
      />

    </div>

  </div>

  <div className="mb-8">

    <label className="text-sm font-semibold text-slate-500">
      Training Mode
    </label>

    <div className="flex gap-8 mt-4">

      <label className="flex items-center gap-2">

        <input
          type="radio"
          name="trainingMode"
          value="Online training"
          checked={form.trainingMode === "Online training"}
          onChange={handleChange}
        />

        Online Training

      </label>

      <label className="flex items-center gap-2">

        <input
          type="radio"
          name="trainingMode"
          value="Classroom training"
          checked={form.trainingMode === "Classroom training"}
          onChange={handleChange}
        />

        Classroom Training

      </label>

    </div>

  </div>

  <div className="mb-8">

    <label className="text-sm font-semibold text-slate-500">
      Sponsored By
    </label>

    <div className="flex gap-8 mt-4">

      <label className="flex items-center gap-2">

        <input
          type="radio"
          name="sponsor"
          value="Self"
          checked={form.sponsor === "Self"}
          onChange={handleChange}
        />

        Self

      </label>

      <label className="flex items-center gap-2">

        <input
          type="radio"
          name="sponsor"
          value="Organization"
          checked={form.sponsor === "Organization"}
          onChange={handleChange}
        />

        Organization

      </label>

    </div>

  </div>

  <div>

    <label className="text-sm font-semibold text-slate-500">
      Special Instructions
    </label>

    <div className="relative mt-2">

      <MessageSquare
        size={20}
        className="absolute left-4 top-4 text-slate-400"
      />

      <textarea
        rows={5}
        name="instructions"
        value={form.instructions}
        onChange={handleChange}
        className="w-full pl-12 pr-5 py-4 rounded-xl border border-slate-300 resize-none focus:border-[#673AB7] focus:ring-4 focus:ring-purple-200 outline-none"
      />

    </div>

  </div>

</div>
<div className="flex justify-between items-center bg-white rounded-2xl shadow-md p-8">

  <p className="text-sm text-slate-500">
    * Required fields
  </p>

  <button
    type="submit"
    disabled={loading}
    className="bg-[#673AB7] hover:bg-[#5E35B1] text-white px-10 py-4 rounded-xl font-bold text-lg shadow-lg transition-all hover:scale-105 flex items-center gap-3"
  >

    {loading ? "Submitting..." : "Continue"}

    {!loading && (
      <ArrowRight size={20} />
    )}

  </button>

</div>

</form>

</div>

</div>

);
}